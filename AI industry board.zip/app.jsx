// Main App - AI Industry Dashboard
const { useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "colorConvention": "us",
  "timeWindow": "6M",
  "density": "balanced"
}/*EDITMODE-END*/;

const App = () => {
  const [convention, setConvention] = useState(TWEAK_DEFAULTS.colorConvention);
  const [timeWindow, setTimeWindow] = useState(TWEAK_DEFAULTS.timeWindow);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-convention', convention);
  }, [convention]);

  useEffect(() => {
    const handler = (e) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const persist = (partial) => {
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: partial }, '*');
  };

  // Aggregate stats for topbar
  const allSectors = INDUSTRY_CHAIN.flatMap(l => l.sectors);
  const avgChange = allSectors.reduce((s, x) => s + x.totalChange, 0) / allSectors.length;
  const bestSector = [...allSectors].sort((a, b) => b.totalChange - a.totalChange)[0];
  const worstSector = [...allSectors].sort((a, b) => a.totalChange - b.totalChange)[0];

  const now = new Date();
  const timeStr = now.toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div className="dashboard">
      {/* Top bar */}
      <div className="topbar">
        <div className="brand">
          <div className="brand-logo">Ai</div>
          <div>
            <div className="brand-title">AI Industry Board</div>
            <div className="brand-sub">Full-Stack · Live Tracker</div>
          </div>
        </div>
        <div className="topbar-right">
          <div className="live-chip"><span className="pulse-dot"></span> LIVE · {timeStr}</div>
          <div className="topbar-stat">
            <span className="lbl">Sectors Avg 6M</span>
            <span className="val" style={{ color: avgChange >= 0 ? 'var(--up)' : 'var(--down)' }}>
              {avgChange >= 0 ? '+' : ''}{avgChange.toFixed(1)}%
            </span>
          </div>
          <div className="topbar-stat">
            <span className="lbl">Best</span>
            <span className="val" style={{ color: 'var(--up)' }}>
              {bestSector.name} +{bestSector.totalChange.toFixed(0)}%
            </span>
          </div>
          <div className="topbar-stat">
            <span className="lbl">Worst</span>
            <span className="val" style={{ color: 'var(--down)' }}>
              {worstSector.name} {worstSector.totalChange.toFixed(0)}%
            </span>
          </div>
        </div>
      </div>

      {/* Section 1: Industry chain */}
      <div className="section">
        <div className="section-header">
          <div className="section-title">
            <h2>产业链分层 · Industry Chain</h2>
            <span className="sub">过去 {timeWindow} · 按周 K 线</span>
            <span className="num">{allSectors.length} SECTORS</span>
          </div>
        </div>

        {INDUSTRY_CHAIN.map((layer, li) => (
          <div className="layer" key={layer.id}>
            <div className="layer-header">
              <span className="layer-idx">L{li + 1}</span>
              <h3>{layer.name}</h3>
              <span className="layer-sub">{layer.nameEn} · {layer.sectors.length} 个细分</span>
            </div>
            <div className="sector-grid">
              {layer.sectors.map(s => <SectorCard key={s.id} sector={s} />)}
            </div>
          </div>
        ))}
      </div>

      {/* Section 2: Key metrics */}
      <div className="section">
        <div className="section-header">
          <div className="section-title">
            <h2>关键数据追踪 · Key Metrics</h2>
            <span className="sub">算力 · 模型 · 投资 · 电力</span>
            <span className="num">{KEY_METRICS.length} SIGNALS</span>
          </div>
        </div>
        <div className="metrics-grid">
          {KEY_METRICS.map(m => <MetricCard key={m.id} m={m} />)}
        </div>
      </div>

      {/* Section 3: News */}
      <div className="section">
        <div className="section-header">
          <div className="section-title">
            <h2>AI 产业动态 · News Wire</h2>
            <span className="sub">模型发布 · 收并购 · 融资 · 政策</span>
            <span className="num">{NEWS.length} ITEMS</span>
          </div>
        </div>
        <NewsFeed items={NEWS} />
      </div>

      {/* Tweaks Panel */}
      <div className={`tweaks-panel ${tweaksOpen ? 'visible' : ''}`}>
        <div className="tweaks-title">
          <span style={{ width: 6, height: 6, borderRadius: 3, background: 'var(--accent)', boxShadow: '0 0 8px var(--accent-glow)' }}></span>
          Tweaks
        </div>
        <div className="tweaks-row">
          <div className="tweaks-row-lbl">涨跌颜色约定</div>
          <div className="tweaks-btn-group">
            <button className={`tweaks-btn ${convention === 'us' ? 'active' : ''}`}
              onClick={() => { setConvention('us'); persist({ colorConvention: 'us' }); }}>
              绿涨红跌
            </button>
            <button className={`tweaks-btn ${convention === 'cn' ? 'active' : ''}`}
              onClick={() => { setConvention('cn'); persist({ colorConvention: 'cn' }); }}>
              红涨绿跌
            </button>
          </div>
        </div>
        <div className="tweaks-row">
          <div className="tweaks-row-lbl">时间窗口</div>
          <div className="tweaks-btn-group">
            {['1M','3M','6M','1Y'].map(w => (
              <button key={w}
                className={`tweaks-btn ${timeWindow === w ? 'active' : ''}`}
                onClick={() => { setTimeWindow(w); persist({ timeWindow: w }); }}>
                {w}
              </button>
            ))}
          </div>
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-lo)', lineHeight: 1.5, marginTop: 6, paddingTop: 10, borderTop: '1px solid var(--border-subtle)' }}>
          时间窗口目前为展示开关 —— K 线数据将在接入真实行情后随之切换。
        </div>
      </div>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
